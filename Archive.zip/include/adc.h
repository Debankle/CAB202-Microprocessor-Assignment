#include <avr/interrupt.h>
#include <avr/io.h>
#include <stdint.h>

#ifndef __ASSIGNMENT_ADC_H
#define __ASSIGNMENT_ADC_H

void adc_init(void);

#endif  // __ASSIGNMENT_ADC_H